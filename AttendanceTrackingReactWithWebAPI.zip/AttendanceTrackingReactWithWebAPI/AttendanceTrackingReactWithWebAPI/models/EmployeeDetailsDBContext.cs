﻿using Microsoft.EntityFrameworkCore;

namespace AttendanceTrackingReactWithWebAPI.models
{
    public class EmployeeDetailsDBContext:DbContext
    {
        public EmployeeDetailsDBContext(DbContextOptions<EmployeeDetailsDBContext> options) : base(options)
        {

        }

        public DbSet<EmployeeDetails> Employees { get; set; }
    }
}
