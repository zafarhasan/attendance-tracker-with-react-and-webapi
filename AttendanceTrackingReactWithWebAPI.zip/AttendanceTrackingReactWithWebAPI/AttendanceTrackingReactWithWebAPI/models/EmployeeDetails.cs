﻿using Microsoft.AspNetCore.Http;
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;

namespace AttendanceTrackingReactWithWebAPI.models
{
    public class EmployeeDetails
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [JsonIgnore]
        public int id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string ManagerName { get; set; }
        [JsonIgnore]
        public DateTime? LoginTime { get; set; }
        [JsonIgnore]
        public string IsEntry { get; set; }
        public string ImageName { get; set; }
        [NotMapped]
        public IFormFile ImageFile { get; set; }
        [NotMapped]
        public string ImageSrc { get; set; }

    }
}
